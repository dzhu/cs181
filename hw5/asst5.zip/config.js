{
    "title": "CS181 Homework 5",
    "subtitle": "Markov Decision Processes",
    "workmodule": "mdp.py",
    "testmodule": "test_mdp.py",
    "taskmodule": "task_mdp.py",
    "usertestdir": "usertests",
    "build_call_graph": false,
    "indent": 4,
    "static": ["darts.py", "modelbased.py", "modelfree.py", "hw5", "hw5.bat", "Makefile", "submit.sh" ]
}
